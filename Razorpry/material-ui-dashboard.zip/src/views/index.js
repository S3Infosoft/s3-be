import Dashboard from './dashboard';

export { Dashboard };
